package ca.uottawa.seg3102.temperatureconverterapipractice

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class TemperatureConverterApiPracticeApplicationTests {

	@Test
	fun contextLoads() {
	}

}
