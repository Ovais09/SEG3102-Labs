# name: Ovais Azeem
## student number: 300112311

To run this code do <code>./gradlew bootRun</code>

The credentials are: 
1. user1 and pass1
2. user2 and pass2


There will be a whitelabel error after the you have successfully logged in, go to

this url: http://localhost:8080/calculator/{operation}/{number1}/{number2}
after you have logged in.